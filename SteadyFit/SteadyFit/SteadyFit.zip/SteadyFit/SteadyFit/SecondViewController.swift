//
//  SecondViewController.swift
//  SteadyFit
//
//  Created by Raheem Mian on 2018-10-23.
//  Copyright © 2018 Raheem Mian. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    var sampleMyGroups = ["Group A", "Group B", "Group C"]
    var sampleRecommentedGroups = ["Group X", "Group Y", "Group Z"]
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return sampleMyGroups.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: UITableViewCell.CellStyle.default, reuseIdentifier: "groupCell")
        cell.textLabel?.text = sampleMyGroups[indexPath.row]
        return cell
    }
    

    @IBOutlet weak var groupTableView: UITableView!

    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func groupTableSwtich(_ sender: UISegmentedControl) {
        
        
    }
}

